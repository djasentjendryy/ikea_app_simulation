#include<stdio.h>
#include<stdlib.h>
#include<conio.h>
#include<string.h>
#include <windows.h>


typedef struct barang{
    char nama[100];
    char harga[50];
    char kodebarang[10];

}barang;
void setcolor(unsigned short color){
    HANDLE hcon = GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleTextAttribute(hcon,color);
    }

void logo (){
    setcolor(1);printf("111111111111111111111111111111111111111111111111111111111111111111\n");printf("11111111");
    setcolor(14);printf("00000000000000000000000000000000000000000000000000");
    setcolor(1);printf("11111111\n");printf("111111");
    setcolor(14);printf("000000000000000000000000000000000000000000000000000000");
    setcolor(1);printf("111111\n");printf("1111");
    setcolor(14);printf("0000000000000000000000000000000000000000000000000000000000");
    setcolor(1);printf("1111\n");printf("111");
    setcolor(14);printf("000000");
    setcolor(1);printf("1111");
    setcolor(14);printf("0000");
    setcolor(1);printf("1111");
    setcolor(14);printf("000");
    setcolor(1);printf("111");
    setcolor(14);printf("0000");
    setcolor(1);printf("1111111");
    setcolor(14);printf("0000000");
    setcolor(1);printf("1111111");
    setcolor(14);printf("00000000000");
    setcolor(1);printf("111\n");printf("11");
    setcolor(14);printf("0000000");
    setcolor(1);printf("1111");
    setcolor(14);printf("0000");
    setcolor(1);printf("1111");
    setcolor(14);printf("00");
    setcolor(1);printf("111");
    setcolor(14);printf("00000");
    setcolor(1);printf("1111");
    setcolor(14);printf("000000000");
    setcolor(1);printf("111");
    setcolor(14);printf("00");
    setcolor(1);printf("1111");
    setcolor(14);printf("00000000000");
    setcolor(1);printf("11\n");
    setcolor(14);printf("000000000");
    setcolor(1);printf("1111");
    setcolor(14);printf("0000");
    setcolor(1);printf("111111");
    setcolor(14);printf("00000000");
    setcolor(1);printf("1111111");
    setcolor(14);printf("00000");
    setcolor(1);printf("111");
    setcolor(14);printf("0000");
    setcolor(1);printf("1111");
    setcolor(14);printf("000000000000\n");
    setcolor(1);printf("11");
    setcolor(14);printf("0000000");
    setcolor(1);printf("1111");
    setcolor(14);printf("0000");
    setcolor(1);printf("1111");
    setcolor(14);printf("00");
    setcolor(1);printf("111");
    setcolor(14);printf("00000");
    setcolor(1);printf("1111");
    setcolor(14);printf("0000000");
    setcolor(1);printf("1111111111111");
    setcolor(14);printf("000000000");
    setcolor(1);printf("11\n");/*baris ke-8*/printf("111");
    setcolor(14);printf("000000");
    setcolor(1);printf("1111");
    setcolor(14);printf("0000");
    setcolor(1);printf("1111");
    setcolor(14);printf("000");
    setcolor(1);printf("111");
    setcolor(14);printf("0000");
    setcolor(1);printf("1111111");
    setcolor(14);printf("000");
    setcolor(1);printf("111");
    setcolor(14);printf("00000000");
    setcolor(1);printf("11111");
    setcolor(14);printf("000000");
    setcolor(1);printf("111\n");/* baris ke-9*/printf("11111");
    setcolor(14);printf("0000000000000000000000000000000000000000000000000000000000");
    setcolor(1);printf("111\n");/* baris ke-9*/printf("111111");
    setcolor(14);printf("000000000000000000000000000000000000000000000000000000");
    setcolor(1);printf("111111\n");/* baris ke-10*/printf("11111111");
    setcolor(14);printf("00000000000000000000000000000000000000000000000000");
    setcolor(1);printf("11111111\n");/* baris ke-11*/
    printf("111111111111111111111111111111111111111111111111111111111111111111\n");/* baris ke-12*/
    setcolor(15);
}

void registerasi()
{
    char nama[50];
    char alamat[50];
    char telp[15];
    char email[50];
    system("cls");
    logo();
    printf("REGISTRASI\n\n");
    printf("Nama Lengkap : ");
    scanf("%s\n",&nama);
    printf("Alamat Pembeli : ");
    scanf("%s",&alamat);
    printf("Nomer Telp/HP : ");
    scanf("%s",&telp);
    printf("Alamat Email : ");
    scanf("%s",&email);

}

void login ()
{
    char email[50];
    char password[25];
    system("cls");
    logo();
    printf("LOGIN\n\n");
    printf("Alamat Email : ");
    scanf("%s",&email);
    printf("Password : ");
    scanf("%s",&password);
}

void belanja()
{
    struct barang item[1000];
    char kategori[100];
    int pilihan,count=0;
    Read(item,&count);
    system("cls");
    logo();
    printf("KATEGORI\n\n");
    printf("1. Meja Bar\n");
    printf("2. Meja Makan\n");
    printf("3. Meja Rias\n");
    printf("4. Meja Tamu\n");
    printf("5. Kursi\n");
    printf("6. Kursi Bar\n");
    printf("7. Kursi Tangga\n");
    printf("8. Kursi Kantor\n");
    printf("9. Kursi Berlengan\n");
    printf("10. Kursi Makan\n");
    printf("11. Lampu LED\n");
    printf("12. Lampu Sorot\n");
    printf("13. Lampu Meja\n");
    printf("14. Lampu Kerja\n");
    printf("15. Lampu Dekorasi\n");
    printf("16. Lemari Berlaci\n");
    printf("17. Lemari Sepatu\n");
    printf("18. Lemari Pakaian\n");
    printf("19. Rak TV\n");
    printf("20. Sofa\n");
    printf("21. Karpet\n");
    printf("22. Bantal\n");
    printf("23. Guling\n");
    printf("24. Selimut\n");
    printf("25. Kasur\n");
    printf("26. Search\n");
    printf("Pilih : ");
    scanf("%d",&pilihan);
    switch(pilihan)
    {
        case 1 :
        strcpy(kategori,"meja bar");
        break;
    case 2 :
        strcpy(kategori,"meja makan");
        break;
    case 3 :
        strcpy(kategori,"Meja rias");
        break;
    case 4 :
        strcpy(kategori,"Meja tamu");
        break;
    case 5 :
        strcpy(kategori,"Kursi");
        break;
    case 6 :
        strcpy(kategori,"Kursi bar");
        break;
    case 7 :
        strcpy(kategori,"Kursi tangga");
        break;
    case 8 :
        strcpy(kategori,"Kursi kantor");
        break;
    case 9 :
        strcpy(kategori,"Kursi berlengan");
        break;
    case 10 :
        strcpy(kategori,"Kursi makan");
        break;
    case 11 :
        strcpy(kategori," Lampu led");
        break;
    case 12 :
        strcpy(kategori,"Lampu sorot");
        break;
    case 13 :
        strcpy(kategori,"Lampu meja");
        break;
    case 14 :
        strcpy(kategori,"Lampu kerja");
        break;
    case 15 :
        strcpy(kategori,"Lampu dekorasir");
        break;
    case 16 :
        strcpy(kategori,"Lemari berlaci");
        break;
    case 17 :
        strcpy(kategori,"Lemari sepatu");
        break;
    case 18 :
        strcpy(kategori,"Lemari pakaian");
        break;
    case 19 :
        strcpy(kategori,"Rak tv");
        break;
    case 20 :
        strcpy(kategori,"sofa");
        break;
    case 21 :
        strcpy(kategori,"Karpet");
        break;
    case 22 :
        strcpy(kategori,"Bantal");
        break;
    case 23 :
        strcpy(kategori,"Guling");
        break;
    case 24 :
        strcpy(kategori,"Selimut");
        break;
    case 25 :
        strcpy(kategori,"Kasur");
        break;
    case 26 :
        strcpy(kategori,"Search");
        break;
    } search(item,count,kategori);
}

void menuutama()
{
    int count = 0;
    struct barang item[1000];
    Read(item,&count);
    int pilih;
    system("cls");
    logo();
    printf("=======================================================================================================================");
    printf("\t\t\t\t\t\t\t1. Registrasi | 2. Log In \n");
    printf("\t\t\t\t\t\t    3. Lanjut Belanja\n");
    printf("=======================================================================================================================\n");
    printf("\t\t\t\t\t\t\tPilih :");
    scanf("%d",&pilih);
    if (pilih==1)
    {
        registerasi();
    }
    else if (pilih==2)
    {
        login();
    }
    else if (pilih==3)
    {
        belanja();
    }
    else
    {
        printf("Pilihan Menu Tidak Tersedia");
    }
}

void Read(struct barang item [], int *n){
    FILE *pt;
    pt = fopen("ListBarang.txt","r");
    while(!feof(pt)){
        fscanf(pt,"%[^$]$%[^$]$%s\n",item[*n].kodebarang,item[*n].nama,item[*n].harga);
        fflush(stdin);
        (*n)++;
    }
    fclose(pt);
}

void menu(int *n){
    do{
    system("cls");
    logo();
    menuutama();
    printf("\nMenu \n\n");
    printf("=======================================================================================================================");
    printf("\t\t\t\t\t\t\t1. Registrasi | 2. Log In \n");
    printf("\t\t\t\t\t\t    3. Lanjut Belanja\n");
    printf("=======================================================================================================================\n");
    printf("\t\t\t\t\t\t\t\t\t\t\t\t0.Keluar Dari Program\n\n");
    printf("Pilih : ");
    scanf("%d",&*n);fflush(stdin);
    }while((*n) < 0 || (*n) > 3 );
}

void search(barang item [], int *n, char kata[])
{
    int i,a;
    char kataKecil[50];
    char kodeKecil[50];

    for (i = 0; i<n;i++)
    {
        for(a = 0; a <= strlen(kata) ;a++)
        {
            kataKecil[a] = tolower(kata[a]);
        }
        for(a = 0; a <= strlen(item[i].nama) ;a++)
        {
            kodeKecil[a] = tolower(item[i].nama[a]);
        }
        if(strstr(kodeKecil, kataKecil )!=0)
        {
            printf("%-20s - %-50s - %-10s\n", item[i].kodebarang, item[i].nama, item[i].harga);
        }

    }

    getch();
}




void menu1()
{
    printf("menu 1 berhasil");
    getchar();
}

void menu2()
{
    printf("menu 2 berhasil");
    getchar();
}

void menu3(barang item[],int *n)
{
    printf("menu 3 berhasil\n");
    char kata[100];
    scanf("%[^\n]",&kata);
    search(item,n,kata);
}

int main ()
{
    int pilih,i, count = 0;
    struct barang item[1000];
    Read(item,&count);

    do{
        system("cls");
        menu(&pilih);
        system("cls");
        logo();
        switch(pilih){
        case 1 : for(i = 0 ; i < count; i++){
        printf("%s == %s .. %s\n", item[i].kodebarang,item[i].nama,item[i].harga);
    };
            break;
        case 2 : menu2();
            break;
        case 3 : menu3(item,count);
            break;
        }
    }while(pilih != 0);

    printf("progam berhenti");


    return 0;
}
